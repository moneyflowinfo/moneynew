# cloud_function/main.py
# This file serves as the entry point for the Google Cloud Function.
# The entry point name in GCF will be 'app'

from api import app